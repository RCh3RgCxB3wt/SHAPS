% Rayleigh BER for L_ch = 4, 6, 8: simulation vs semi-analytical theory

% settings
QUICK_TEST = false;     % true for a quick smoke test

PAR_MODE   = 'auto';    % 'auto' | 'threads' | 'processes' | 'serial'
N_WORKERS  = [];
PLAIN_MC   = true;      % keep true to reproduce the figures exactly
GENIE      = true;      % ideal side info, diagnostic only
CASES      = [4 6 8];

snr_mc = [4 7 10 13 16 19 22 25 28 30];
cases = struct( ...
    'L_ch',      {4, 6, 8}, ...
    'L_cp',      {8, 10, 12}, ...
    'N_seg',     {3000, 3000, 5000}, ...
    'snr_shaps', {[4 7 10 13 16 19 22 25], [4 7 10 13 16 19 22 25], [4 7 10 13 16 19 22 25]}, ...
    'fig',       {'fig3_rayleigh_L4_ber', 'fig4_rayleigh_L6_ber', 'fig5_rayleigh_L8_ber'}, ...
    'y_min',     {1e-5, 8e-7, 1e-7});
cases = cases(ismember([cases.L_ch], CASES));

nW = setup_parallel(PAR_MODE, N_WORKERS);
opt_s = struct('N_seg', [], 'N_pool', 1e6, 'eps', 0.3, 'seed', 1, 'plain', PLAIN_MC, ...
               'nW', nW, 'block', 100, 'genie', GENIE);
opt_c = struct('N_frames', [], 'batch', 1000, 'seed', 1, 'nW', nW);
if QUICK_TEST
    opt_s.N_pool = 1e5;  opt_s.block = 20;  opt_c.N_frames = 2000;
end

out_dir = 'results_rayleigh';
if ~exist(out_dir, 'dir'), mkdir(out_dir); end
t_all = tic;

for ci = 1:numel(cases)
    cs = cases(ci);  L = cs.L_ch;
    tag = sprintf('L%d', L);
    p  = shaps_params(cs.L_cp);
    opt_s.N_seg = cs.N_seg;
    if QUICK_TEST, p.N_mc = 1e5; p.N_mc_shaps = 1e5; opt_s.N_seg = 40; end
    cfg = struct('walsh', 1, 'zc', 1, 'slm', 1, 'mu', p.mu0);
    fprintf('\n==== Rayleigh L_ch = %d, L_cp = %d, eta_S = %.3f ====\n', L, p.L_cp, p.eta_S);

    rs = sim_shaps_rayleigh(cs.snr_shaps, p, cfg, L, opt_s);
    for i = 1:numel(cs.snr_shaps)
        fprintf(['  SHAPS   %4.1f dB | BER %.3e +- %4.1f%% | same-ch. theory %.3e | ' ...
                 'ratio %.2f +- %.2f (ideal SI %.2f +- %.2f) | theory %.3e | idx err sim %.1e, union %.1e\n'], ...
                cs.snr_shaps(i), rs.ber(i), 100*rs.se(i)/max(rs.ber(i), eps), rs.th_same(i), ...
                rs.ratio(i), rs.ratio_se(i), rs.ratio_g(i), rs.ratio_g_se(i), rs.th_full(i), ...
                rs.idx_err(i), rs.idx_ub_full(i));
    end
    roc = sim_mcdcsk_rayleigh(snr_mc, p, 'ocdm', L, opt_c);
    rof = sim_mcdcsk_rayleigh(snr_mc, p, 'ofdm', L, opt_c);
    for i = 1:numel(snr_mc)
        fprintf('  MC-OCDM %4.1f dB | BER %.3e (ratio %.2f)   MC-OFDM BER %.3e (ratio %.2f)\n', ...
                snr_mc(i), roc.ber(i), roc.ratio(i), rof.ber(i), rof.ratio(i));
    end

    % theory curves
    x_s  = cs.snr_shaps(1):0.5:cs.snr_shaps(end);
    x_m  = snr_mc(1):0.5:snr_mc(end);
    [th_s, th_s_se] = theory_rayleigh(x_s, p, L, 'shaps');
    fprintf('  SHAPS theory curve: %.0e draws, max relative SE %.1f %%\n', p.N_mc_shaps, ...
            100*max(th_s_se ./ th_s));
    th_oc = theory_rayleigh(x_m, p, L, 'mc_ocdm');
    th_of = theory_rayleigh(x_m, p, L, 'mc_ofdm');
    thp_oc = theory_rayleigh(snr_mc, p, L, 'mc_ocdm');
    thp_of = theory_rayleigh(snr_mc, p, L, 'mc_ofdm');

    fig = rayleigh_figure(x_s, th_s, x_m, th_oc, th_of, cs.snr_shaps, rs.ber, ...
                          snr_mc, roc.ber, rof.ber, cs.y_min);
    exportgraphics(fig, fullfile(out_dir, [cs.fig '.png']), 'Resolution', 200);
    savefig(fig, fullfile(out_dir, [cs.fig '.fig']));

    res = struct('shaps', rs, 'ocdm', roc, 'ofdm', rof, 'x_s', x_s, 'th_s', th_s, 'th_s_se', th_s_se, ...
                 'eta_S', p.eta_S, ...
                 'x_m', x_m, 'th_oc', th_oc, 'th_of', th_of, 'thp_oc', thp_oc, 'thp_of', thp_of);
    results.(tag) = res;
    close(fig);
    print_paper_numbers(L, cs.snr_shaps, rs, snr_mc, roc, rof);
    fprintf('  [L_ch = %d done, total %.1f min]\n', L, toc(t_all)/60);
end
if ~exist('results', 'var'), results = struct(); end
fprintf('\nfigures (.png/.fig) written to %s/\n', out_dir);



function print_paper_numbers(L, xs, rs, xm, roc, rof)
% print key numbers at a few SNR points
fprintf('  ---- numbers for the paper (L_ch = %d) ----\n', L);
for s = [10 19 22 25]
    i = find(xs == s, 1);  k = find(xm == s, 1);
    if isempty(i) || isempty(k), continue; end
    fprintf('  %2d dB: SHAPS %.2e (+-%.0f%%)  MDCSK-OCDM %.2e  gain %.0fx | idx err %.1e\n', ...
            s, rs.ber(i), 100*rs.se(i)/rs.ber(i), roc.ber(k), roc.ber(k)/rs.ber(i), rs.idx_err(i));
end
fprintf('  classical sim/theory: MDCSK-OCDM %.2f-%.2f, MDCSK-OFDM %.2f-%.2f\n', ...
        min(roc.ratio), max(roc.ratio), min(rof.ratio), max(rof.ratio));
end
