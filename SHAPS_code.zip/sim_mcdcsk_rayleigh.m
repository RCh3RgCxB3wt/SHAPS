function r = sim_mcdcsk_rayleigh(snr, p, basis, L_ch, opt)
% Monte-Carlo BER of MDCSK-OCDM/OFDM over Rayleigh fading (new channel per frame)
if nargin < 5, opt = struct(); end
if ~isfield(opt, 'batch'), opt.batch = 1000; end
if ~isfield(opt, 'seed'),  opt.seed  = 1;    end
if ~isfield(opt, 'nW'),    opt.nW    = 0;    end
if ~isfield(opt, 'verbose'), opt.verbose = true; end
nW = opt.nW;  t0 = tic;
snr = snr(:).';  nS = numel(snr);
if ~isfield(opt, 'N_frames') || isempty(opt.N_frames)
    opt.N_frames = 2e4 * ones(1, nS);  opt.N_frames(snr >= 22) = 1e5;
elseif isscalar(opt.N_frames)
    opt.N_frames = opt.N_frames * ones(1, nS);
end
switch basis
    case 'ocdm', scheme = 'mc_ocdm';
    case 'ofdm', scheme = 'mc_ofdm';
    otherwise, error('sim_mcdcsk_rayleigh: unknown basis ''%s''', basis);
end
B = opt.batch;  Kc = p.M - 1;
r.ber = zeros(1, nS); r.se = zeros(1, nS); r.th_same = zeros(1, nS);
r.n_frames = zeros(1, nS);
for i = 1:nS
    nBatch = ceil(opt.N_frames(i) / B);
    s1 = zeros(nBatch, 1); s2 = zeros(nBatch, 1); st = zeros(nBatch, 1);
    seed_i = 100000*opt.seed + 1000*L_ch + 10*i + strcmp(basis, 'ofdm');
    EbN0 = snr(i);
    parfor (k = 1:nBatch, nW)
        rs = RandStream('mrg32k3a', 'Seed', seed_i);
        rs.Substream = k;     % independent stream per batch
        [e, th] = one_batch(B, EbN0, p, basis, scheme, L_ch, rs);
        x = e / Kc;
        s1(k) = sum(x); s2(k) = sum(x.^2); st(k) = sum(th);
    end
    n = nBatch * B;
    m = sum(s1) / n;
    r.ber(i)     = m;
    r.se(i)      = sqrt(max(sum(s2)/n - m^2, 0) / n);
    r.th_same(i) = sum(st) / n;
    r.n_frames(i) = n;
    if opt.verbose
        fprintf('    MDCSK-%s L_ch=%d: %4.1f dB done (%d frames) | %6.1f min\n', ...
                upper(basis), L_ch, EbN0, n, toc(t0)/60);
    end
end
r.ratio = r.ber ./ r.th_same;
r.snr = snr;
end


function [e, th] = one_batch(B, EbN0_dB, p, basis, scheme, L_ch, rs)
% B frames, each with its own channel
M = p.M; beta = p.beta; L_cp = p.L_cp; N = p.N; Kc = M - 1;
g = 10^(EbN0_dB/10);
% transmitter
b   = 2*randi(rs, [0 1], Kc, B) - 1;
Phi = zeros(beta, B);
for f = 1:B
    x0 = (2*randi(rs, [0 1]) - 1) * (0.1 + 0.8*rand(rs));
    Phi(:, f) = chebyshev_chaos(beta, x0);
end
U = zeros(M, beta, B);
U(1, :, :)   = reshape(Phi, 1, beta, B);
U(2:M, :, :) = reshape(b, Kc, 1, B) .* reshape(Phi, 1, beta, B);
switch basis
    case 'ocdm', X = reshape(p.A * reshape(U, M, beta*B), M, beta, B);
    case 'ofdm', X = ifft(U, M, 1) * sqrt(M);
end
X = cat(1, X(end-L_cp+1:end, :, :), X);
x = reshape(X, N, B);
% Rayleigh channel
h = (randn(rs, L_ch, B) + 1j*randn(rs, L_ch, B)) / sqrt(2*L_ch);
y = h(1, :) .* x;
for l = 2:L_ch
    y(l:end, :) = y(l:end, :) + h(l, :) .* x(1:end-l+1, :);
end
N0 = sum(abs(x).^2, 1) / Kc / g;
y  = y + sqrt(N0/2) .* (randn(rs, N, B) + 1j*randn(rs, N, B));
% receiver
Y   = reshape(y, M + L_cp, beta, B);
Y   = Y(L_cp+1:end, :, :);
Hm  = fft(h, M, 1);
reg = N / (Kc * g);
Lam = reshape(conj(Hm) ./ (abs(Hm).^2 + reg), M, 1, B);   % MMSE weights
switch basis
    case 'ocdm'
        Y = ifft(Lam .* fft(Y, M, 1), M, 1);
        V = reshape(p.A' * reshape(Y, M, beta*B), M, beta, B);
    case 'ofdm'
        V = fft(Y, M, 1) / sqrt(M) .* Lam;
end
rho   = real(sum(V(2:M, :, :) .* conj(V(1, :, :)), 2));
b_hat = sign(reshape(rho, Kc, B));
b_hat(b_hat == 0) = 1;
e  = sum(b_hat ~= b, 1);
th = cond_ber_rayleigh(abs(Hm).^2, EbN0_dB, p, L_ch, scheme);
end
