function A = chirp_basis(M)
% OCDM chirp matrix (IDFnT), unitary
assert(mod(M,2) == 0, 'M must be even');
n = (0:M-1).';  m = 0:M-1;
A = exp(-1j*pi/4) / sqrt(M) * exp(1j*pi/M * (n - m).^2);
end
