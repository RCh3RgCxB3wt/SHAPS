function Y = mmse_equalize(Y, h, EbN0_dB, K, p)
% Frequency-domain MMSE equalizer (FFT -> MMSE -> IFFT)
M   = p.M;
Hm  = fft(h(:), M);
reg = p.N / (K * 10^(EbN0_dB/10));   % noise-to-signal ratio
Lam = conj(Hm) ./ (abs(Hm).^2 + reg);
Y   = ifft(Lam .* fft(Y, M, 1), M, 1);
end
