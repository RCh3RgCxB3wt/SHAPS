function p = shaps_params(L_cp)
% System parameters of SHAPS-MDCSK-OCDM (default L_cp = 8)

if nargin < 1 || isempty(L_cp), L_cp = 8; end

p.M     = 32;                     % number of subcarriers
p.beta  = 64;                     % spreading length
p.K     = p.M;
p.L_cp  = L_cp;
p.T_R   = 50;                     % pilot refresh period (frames)
p.KEY   = 0.618033988749895;      % shared key
p.N_slm = 16;
p.mu0   = 8;                      % mu-law factor
p.O_s   = 4;
p.N     = (p.M + p.L_cp) * p.beta;

% side information
p.si_mode       = 'peak';         % 'peak' or 'genie'
p.eb_include_si = false;

p.n_b  = ceil(log2(p.N_slm));
p.n_si = 32;
saved = rng;
rng(777, 'twister');              % fixed signature, same at both ends
p.si_sig = 2*randi([0 1], p.n_si, 1) - 1;
rng(saved);
Hs = walsh_had(p.n_si);
p.si_tab = p.si_sig .* Hs(:, 1:p.N_slm);       % codeword table

% coefficients for the Rayleigh model
p.C_W   = 4;
p.eta_S = 0.02;
p.chi_c = 4/3;
p.eta   = 1;
p.eta_s = 1/20;
p.N_mc  = 1e6;
p.N_mc_shaps = 1e7;
p.N_mc_chunk = 1e5;

% pre-stored matrices
p.A  = chirp_basis(p.M);
p.Wh = walsh_had(p.beta);
p.Za = zc_subcarrier(p.M, p.beta);
p.G  = gen_phase_set(p.M, p.beta, p.N_slm);
p.walsh_rows = mod((0:p.M-1).', p.beta) + 1;
end
