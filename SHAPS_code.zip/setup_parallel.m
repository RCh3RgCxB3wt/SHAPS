function nW = setup_parallel(mode, n_req)
% Pick parallel mode for parfor: 'auto' | 'threads' | 'processes' | 'serial'
% nW = 0 means serial run
if nargin < 1 || isempty(mode), mode = 'auto'; end
if nargin < 2, n_req = []; end
nW = 0;
mode = lower(mode);
if strcmp(mode, 'serial')
    fprintf('[parallel] serial run (no pool).\n');
    return
end
has_pct = ~isempty(ver('parallel')) && license('test', 'Distrib_Computing_Toolbox');
if ~has_pct
    fprintf('[parallel] Parallel Computing Toolbox not available: serial run.\n');
    return
end

pool = gcp('nocreate');                       % never creates a pool
if ~isempty(pool)
    nW = pool.NumWorkers;
    fprintf('[parallel] using the existing pool (%s, %d workers).\n', class(pool), nW);
else
    switch mode
        case {'auto', 'threads'}
            try
                pool = parpool('Threads');
                nW = pool.NumWorkers;
                fprintf('[parallel] thread pool started (%d workers).\n', nW);
            catch ME
                fprintf('[parallel] thread pool not available (%s).\n', ME.message);
            end
        case 'processes'
            pctconfig('hostname', 'localhost');   % avoid connection hangs
            try
                if isempty(n_req), pool = parpool('Processes');
                else,              pool = parpool('Processes', n_req);
                end
                nW = pool.NumWorkers;
                fprintf('[parallel] process pool started (%d workers).\n', nW);
            catch ME
                fprintf('[parallel] process pool failed (%s).\n', ME.message);
            end
        otherwise
            error('setup_parallel: unknown mode ''%s''', mode);
    end
end

if nW > 0 && ~smoke_test(nW)
    fprintf('[parallel] smoke test failed on this pool: closing it, serial run.\n');
    delete(gcp('nocreate'));
    nW = 0;
end
if nW == 0
    fprintf('[parallel] serial run. Expect roughly 2-4 h for main_rayleigh_ber.\n');
end
end


function ok = smoke_test(nW)
% quick check that the pool can run the real code
ok = true;
try
    p = shaps_params(8);
    p.T_R = 2;
    cfg = struct('walsh', 1, 'zc', 1, 'slm', 1, 'mu', p.mu0);
    h = [0.8; 0.5; 0.3; 0.1];
    e = zeros(1, 2);
    parfor (j = 1:2, nW)
        rs = RandStream('mrg32k3a', 'Seed', 1);
        rs.Substream = j;
        seg = shaps_tx_segment(j - 1, p, cfg, rs);
        st = rs.State;
        e(j) = shaps_rx_segment(seg, h, 10, p, cfg, rs);
        rs.State = st;
    end
    opt = struct('N_frames', 4, 'batch', 2, 'seed', 9, 'nW', nW, 'verbose', false);
    sim_mcdcsk_rayleigh(10, p, 'ocdm', 4, opt);
    fprintf('[parallel] smoke test passed.\n');
catch ME
    ok = false;
    fprintf('[parallel] smoke test error: %s\n', ME.message);
end
end
