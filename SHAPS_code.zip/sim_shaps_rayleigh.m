function r = sim_shaps_rayleigh(snr, p, cfg, L_ch, opt)
% Monte-Carlo BER of SHAPS over Rayleigh block fading,
% using channel importance sampling (plain MC optional for cross-check)
if nargin < 5, opt = struct(); end
opt = set_default(opt, 'N_seg', 2000);
opt = set_default(opt, 'N_pool', 1e6);
opt = set_default(opt, 'eps', 0.3);
opt = set_default(opt, 'seed', 1);
opt = set_default(opt, 'plain', true);
opt = set_default(opt, 'verbose', true);
opt = set_default(opt, 'block', 100);
opt = set_default(opt, 'nW', 0);
opt = set_default(opt, 'genie', true);
opt = set_default(opt, 'is_idx', true);

snr = snr(:).';  nS = numel(snr);  Nseg = opt.N_seg;  Np = opt.N_pool;
nb  = (p.T_R - 1) * p.K;

% channel pool and model BER
[hpool, pb] = channel_pool(Np, L_ch, snr, p, 'shaps', 1000*opt.seed + L_ch);
r.th_full = mean(pb, 2).';
use_idx = cfg.slm && ~strcmp(p.si_mode, 'genie');
pidx = zeros(size(pb));
if use_idx
    rA = mean(si_amp_ratio(p));
    hi = snr >= 10;                % index errors only matter at high SNR
    if any(hi)
        for c0 = 1:1e5:Np
            c1 = min(c0 + 1e5 - 1, Np);
            pidx(hi, c0:c1) = cond_idx_err(hpool(:, c0:c1), snr(hi), p, rA);
        end
    end
end
r.idx_ub_full = mean(pidx, 2).';
pq = pb;  if opt.is_idx, pq = pb + pidx; end

% draw channel indices (IS and plain)
rs = RandStream('mt19937ar', 'Seed', 2000*opt.seed + L_ch);
idx = zeros(nS, Nseg);  w = zeros(nS, Nseg);  th_is = zeros(nS, Nseg);  pidx_is = th_is;
for i = 1:nS
    q = (1 - opt.eps) * pq(i, :) / sum(pq(i, :)) + opt.eps / Np;   % defensive mixture
    edges = [0, cumsum(q)];  edges(end) = 1;
    idx(i, :)   = discretize(rand(rs, 1, Nseg), edges);
    w(i, :)     = 1 ./ (Np * q(idx(i, :)));                         % IS weights
    th_is(i, :) = pb(i, idx(i, :));
    pidx_is(i, :) = pidx(i, idx(i, :));
end
idx_mc = randi(rs, Np, 1, Nseg);
th_mc  = pb(:, idx_mc);
H_is = zeros(L_ch, nS, Nseg);
for i = 1:nS
    H_is(:, i, :) = reshape(hpool(:, idx(i, :)), L_ch, 1, Nseg);
end
H_mc = hpool(:, idx_mc);
clear hpool pb pq pidx

% segment loop
E_is = zeros(nS, Nseg);  I_is = zeros(nS, Nseg);
E_mc = zeros(nS, Nseg);  I_mc = zeros(nS, Nseg);  E_g = zeros(nS, Nseg);
pg = p;  pg.si_mode = 'genie';  do_genie = opt.genie && cfg.slm;
do_plain = opt.plain;  seed_rx = 3000*opt.seed + L_ch;  nW = opt.nW;
t0 = tic;
for j0 = 0:opt.block:Nseg-1
    jj = j0+1:min(j0 + opt.block, Nseg);  nj = numel(jj);
    Hb_is = H_is(:, :, jj);  Hb_mc = H_mc(:, jj);
    Eb1 = zeros(nS, nj); Ib1 = zeros(nS, nj); Eb2 = zeros(nS, nj); Ib2 = zeros(nS, nj); Eb3 = zeros(nS, nj);
    parfor (k = 1:nj, nW)
        rsj = RandStream('mrg32k3a', 'Seed', seed_rx);
        rsj.Substream = j0 + k;                         % one substream per segment
        seg = shaps_tx_segment(j0 + k - 1, p, cfg, rsj);
        hj = Hb_is(:, :, k);  hm = Hb_mc(:, k);
        e1 = zeros(nS, 1); i1 = zeros(nS, 1); e2 = zeros(nS, 1); i2 = zeros(nS, 1); e3 = zeros(nS, 1);
        for i = 1:nS
            st = rsj.State;                              % same noise for real and ideal SI
            [e1(i), i1(i)] = shaps_rx_segment(seg, hj(:, i), snr(i), p, cfg, rsj);
            if do_genie
                st2 = rsj.State;  rsj.State = st;
                e3(i) = shaps_rx_segment(seg, hj(:, i), snr(i), pg, cfg, rsj);
                rsj.State = st2;
            end
            if do_plain
                [e2(i), i2(i)] = shaps_rx_segment(seg, hm, snr(i), p, cfg, rsj);
            end
        end
        Eb1(:, k) = e1;  Ib1(:, k) = i1;  Eb2(:, k) = e2;  Ib2(:, k) = i2;  Eb3(:, k) = e3;
    end
    E_is(:, jj) = Eb1;  I_is(:, jj) = Ib1;  E_mc(:, jj) = Eb2;  I_mc(:, jj) = Ib2;  E_g(:, jj) = Eb3;
    if opt.verbose
        el = toc(t0);  done = jj(end);
        fprintf('    SHAPS L_ch=%d: %5d/%d segments | %6.1f min | ETA %6.1f min\n', ...
                L_ch, done, Nseg, el/60, el/60*(Nseg - done)/done);
    end
end

% estimators
x  = w .* E_is / nb;
wt = w .* th_is;
r.ber      = mean(x, 2).';
r.se       = (std(x, 0, 2) / sqrt(Nseg)).';
r.th_same  = mean(wt, 2).';
r.ratio    = r.ber ./ r.th_same;
d          = x - r.ratio.' .* wt;                 % delta method for the ratio
r.ratio_se = (std(d, 0, 2) ./ (sqrt(Nseg) * mean(wt, 2))).';
r.idx_err  = mean(w .* I_is, 2).';
r.idx_ub_same = mean(w .* pidx_is, 2).';
r.n_err_raw = sum(E_is, 2).';
if do_genie
    xg = w .* E_g / nb;
    r.ber_g      = mean(xg, 2).';
    r.se_g       = (std(xg, 0, 2) / sqrt(Nseg)).';
    r.ratio_g    = r.ber_g ./ r.th_same;
    dg           = xg - r.ratio_g.' .* wt;
    r.ratio_g_se = (std(dg, 0, 2) ./ (sqrt(Nseg) * mean(wt, 2))).';
else
    r.ber_g = nan(1, nS); r.se_g = nan(1, nS); r.ratio_g = nan(1, nS); r.ratio_g_se = nan(1, nS);
end
if do_plain
    r.ber_mc     = (sum(E_mc, 2) / (nb * Nseg)).';
    r.se_mc      = (std(E_mc / nb, 0, 2) / sqrt(Nseg)).';
    r.th_same_mc = mean(th_mc, 2).';
    r.idx_err_mc = mean(I_mc, 2).';
end
r.snr = snr;  r.n_seg = Nseg;  r.n_bits_per_seg = nb;
end


function s = set_default(s, f, v)
if ~isfield(s, f) || isempty(s.(f)), s.(f) = v; end
end
