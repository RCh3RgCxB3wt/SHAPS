function u_hat = slm_sideinfo_rx(r_si, p, h)
% Decode the SLM index from received side information (h = 1 for AWGN)
if nargin < 3 || isempty(h), h = 1; end
T = p.si_tab;
if ~(isscalar(h) && h == 1)
    T = filter(h, 1, T);                 % codewords through the channel
end
met   = real(T' * r_si);
score = max(met, 0).^2 ./ sum(abs(T).^2, 1).';
[~, u_hat] = max(score);
end
