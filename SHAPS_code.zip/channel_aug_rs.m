function [y, r_si] = channel_aug_rs(x, s_si, h, EbN0_dB, K, p, rs)
% Pass the frame through channel h plus noise (h = 1 means AWGN), using stream rs
N     = numel(x);
x_aug = [x; zeros(p.L_cp, 1); s_si];
if isscalar(h) && h == 1
    y_aug = x_aug;
else
    y_aug = filter(h, 1, x_aug);   % linear convolution with channel taps
end
E = sum(abs(x).^2);
if p.eb_include_si, E = E + sum(abs(s_si).^2); end
N0 = (E / K) / 10^(EbN0_dB/10);
n_aug = numel(x_aug);
y_aug = y_aug + sqrt(N0/2) * (randn(rs, n_aug, 1) + 1j*randn(rs, n_aug, 1));
y    = y_aug(1:N);
r_si = y_aug(N + p.L_cp + 1:end);
end
