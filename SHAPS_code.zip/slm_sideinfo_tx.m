function s_si = slm_sideinfo_tx(u_opt, x, p)
% Side-information block for SLM index u_opt
switch p.si_mode
    case 'peak',  A_si = max(abs(x));
    case 'genie', A_si = 1;
    otherwise, error('slm_sideinfo_tx: unknown si_mode ''%s''', p.si_mode);
end
s_si = A_si * p.si_tab(:, u_opt);
end
