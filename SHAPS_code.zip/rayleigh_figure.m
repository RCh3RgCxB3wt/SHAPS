function fig = rayleigh_figure(x_s, th_s, x_m, th_oc, th_of, xs, ber_s, xm, ber_oc, ber_of, y_min)
% Rayleigh BER figure: theory lines and simulated markers
fig = figure('Position', [100 100 640 560], 'Color', 'w');
th_s(th_s < y_min/2) = NaN;
semilogy(x_s, th_s,  'b-', 'LineWidth', 1.9); hold on;
semilogy(x_m, th_oc, 'r-', 'LineWidth', 1.9);
semilogy(x_m, th_of, 'g-', 'LineWidth', 1.9);
pts(xs, ber_s,  'bo', [0 0 1]);
pts(xm, ber_oc, 'rs', [1 0 0]);
pts(xm, ber_of, 'g^', [0 0.8 0]);
grid on; set(gca, 'YMinorGrid', 'on');
xlabel('$E_{\mathrm{b}}/N_{\mathrm{0}}$ (dB)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('BER', 'FontSize', 12);
xlim([min(xm) max(xm)]); ylim([y_min 1]);
legend('SHAPS-MDCSK-OCDM Theory', 'MDCSK-OCDM Theory', 'MDCSK-OFDM Theory', ...
       'SHAPS-MDCSK-OCDM Simulated', 'MDCSK-OCDM Simulated', 'MDCSK-OFDM Simulated', ...
       'Location', 'southwest');
hold off;
end

function pts(x, y, style, col)
x = x(:).'; y = y(:).'; k = y > 0;
semilogy(x(k), y(k), style, 'MarkerSize', 8, 'MarkerFaceColor', col, 'Color', col, ...
         'LineStyle', 'none');
end
