function S = spread_matrix(M, kind)
% M x M spreading matrix for the low-PAPR baselines: 'ci' | 'dct' | 'none'
k = (0:M-1).';  n = 0:M-1;
switch kind
    case 'ci'
        S = exp(1j*2*pi*k*n/M) / sqrt(M);
    case 'dct'
        S = sqrt(2/M) * cos(pi*(2*n + 1).*k/(2*M));   % orthonormal DCT-II
        S(1, :) = S(1, :) / sqrt(2);
    case 'none'
        S = eye(M);
    otherwise
        error('spread_matrix: unknown kind ''%s''', kind);
end
end
