% PAPR CCDF of SHAPS (shaping on/off) and the DCSK baselines

N_frames = 20000;                  % frames per scheme
SEED     = 2024;
PLOT_BASELINES = true;

p = shaps_params(8);
cfg_on  = struct('walsh', 1, 'zc', 1, 'slm', 1, 'mu', p.mu0);
cfg_off = struct('walsh', 0, 'zc', 0, 'slm', 0, 'mu', 0);
rng(SEED, 'twister');

n_seg = ceil(N_frames / p.T_R);  
N_frames = n_seg * p.T_R;
papr_on = zeros(N_frames, 1);  
papr_off = zeros(N_frames, 1);
c1_on   = zeros(N_frames, 1);  
c1_off   = zeros(N_frames, 1);
fprintf('PAPR of %d frames per scheme ...\n', N_frames);  t0 = tic;
i = 0;
for s = 0:n_seg-1
    c = chebyshev_chaos(p.beta, refresh_x0(s, p.KEY));
    U = repmat(c.', p.M, 1);                         % pilot state
    for t = 1:p.T_R
        if t == 1, b = ones(p.K, 1); 
        else, b = 2*randi([0 1], p.K, 1) - 1; 
        end
        [x_on, U_next] = shaps_tx(b, U, p, cfg_on);
        x_off          = shaps_tx(b, U, p, cfg_off);  % same state, no shaping
        i = i + 1;
        papr_on(i)  = papr_db(x_on,  p.O_s);
        papr_off(i) = papr_db(x_off, p.O_s);
        c1_on(i)    = papr_db(x_on,  1);               
        c1_off(i)   = papr_db(x_off, 1);                
        U = U_next;
    end
end
papr_oc = zeros(N_frames, 1);  
papr_of = zeros(N_frames, 1);
c1_oc   = zeros(N_frames, 1);  
c1_of   = zeros(N_frames, 1);    
B = 500;
for k = 1:B:N_frames
    nb = min(B, N_frames - k + 1);  
    r = k:k+nb-1;
    x = mcdcsk_tx(nb, p, 'ocdm');  
    papr_oc(r) = papr_db(x, p.O_s).';  
    c1_oc(r) = papr_db(x, 1).';
    x = mcdcsk_tx(nb, p, 'ofdm');  
    papr_of(r) = papr_db(x, p.O_s).';  
    c1_of(r) = papr_db(x, 1).';
end

% low-PAPR baselines
papr_ci = zeros(N_frames, 1);  
papr_dc = zeros(N_frames, 1);
c1_ci   = zeros(N_frames, 1);  
c1_dc   = zeros(N_frames, 1);    
for k = 1:B:N_frames
    nb = min(B, N_frames - k + 1);  
    r = k:k+nb-1;
    x = mcdcsk_tx(nb, p, 'ci_ofdm');   
    papr_ci(r) = papr_db(x, p.O_s).';  
    c1_ci(r) = papr_db(x, 1).';
    x = mcdcsk_tx(nb, p, 'dct_ofdm');  
    papr_dc(r) = papr_db(x, p.O_s).';  
    c1_dc(r) = papr_db(x, 1).';
end
fprintf('done in %.1f s\n', toc(t0));

% statistics
names = {'SHAPS-MDCSK-OCDM (four-stage ON)'; 'SHAPS-MDCSK-OCDM (bare, shaping off)'; ...
         'MDCSK-OFDM'; 'MDCSK-OCDM'; 'CI-MDCSK-OFDM'; 'DCT-MDCSK-OFDM'};
data  = {papr_on, papr_off, papr_of, papr_oc, papr_ci, papr_dc};
data1 = {c1_on,   c1_off,   c1_of,   c1_oc,   c1_ci,   c1_dc};      
S = zeros(6, 5);
for k = 1:6
    S(k, :) = [median(data{k}), q_tail(data{k}, 0.99), max(data{k}), ...
               median(data1{k}), q_tail(data1{k}, 0.99)];
end
stats = table(names, S(:,1), S(:,2), S(:,3), S(:,4), S(:,5), 'VariableNames', ...
              {'scheme', 'median_dB', 'p99_dB', 'max_dB', 'chip_median_dB', 'chip_p99_dB'});
disp(stats);
fprintf('Nyquist-rate reduction vs MDCSK-OCDM: median %.2f dB, 99%% %.2f dB\n', S(4,4)-S(1,4), S(4,5)-S(1,5));
fprintf('Nyquist-rate reduction vs MDCSK-OFDM: median %.2f dB, 99%% %.2f dB\n', S(3,4)-S(1,4), S(3,5)-S(1,5));
fprintf('99%% rise from Nyquist rate to 4x: SHAPS %.2f, CI %.2f, DCT %.2f dB\n', ...
        S(1,2)-S(1,5), S(5,2)-S(5,5), S(6,2)-S(6,5));
fprintf('Reduction vs MDCSK-OCDM: median %.2f dB, 99%% %.2f dB\n', S(4,1)-S(1,1), S(4,2)-S(1,2));
fprintf('Reduction vs MDCSK-OFDM: median %.2f dB, 99%% %.2f dB\n', S(3,1)-S(1,1), S(3,2)-S(1,2));
fprintf('Reduction vs CI-MDCSK-OFDM: median %.2f dB, 99%% %.2f dB\n', S(5,1)-S(1,1), S(5,2)-S(1,2));
fprintf('Reduction vs DCT-MDCSK-OFDM: median %.2f dB, 99%% %.2f dB\n', S(6,1)-S(1,1), S(6,2)-S(1,2));

% CCDF figure
xx = linspace(4, 18, 561);
ccdf = @(a) mean(a(:) > xx, 1);
fig = figure('Color', 'w', 'Position', [100 100 640 560]);
semilogy(xx, ccdf(papr_on), 'b-',  'LineWidth', 2); hold on;
semilogy(xx, ccdf(papr_oc), 'r-',  'LineWidth', 2);
semilogy(xx, ccdf(papr_of), '-',   'Color', [0 0.8 0], 'LineWidth', 2);
semilogy(xx, ccdf(papr_off), 'k--', 'LineWidth', 1.2);

leg = {'SHAPS-MDCSK-OCDM', 'MDCSK-OCDM', 'MDCSK-OFDM', 'SHAPS, shaping off'};
if PLOT_BASELINES
    semilogy(xx, ccdf(papr_ci), '-.', 'Color', [0.6 0 0.8], 'LineWidth', 2);
    semilogy(xx, ccdf(papr_dc), '-.', 'Color', [0.9 0.5 0], 'LineWidth', 2);
    leg = [leg, {'CI-MDCSK-OFDM', 'DCT-MDCSK-OFDM'}];
end
yline(1e-2, ':', '99% (CCDF = 10^{-2})', 'Color', [.4 .4 .4], ...
      'LabelHorizontalAlignment', 'left');            
grid on; 
ylim([1e-3 1]); 
xlim([xx(1) xx(end)]);
xlabel('PAPR_0 (dB)'); 
ylabel('CCDF = Pr(PAPR > PAPR_0)');
legend(leg, 'Location', 'northeast', 'FontSize', 9); 

out_dir = 'results_papr';
if ~exist(out_dir, 'dir'), mkdir(out_dir); 
end
saveas(fig, fullfile(out_dir, 'papr_ccdf.png'));
savefig(fig, fullfile(out_dir, 'papr_ccdf.fig'));



function q = q_tail(a, prob)
% empirical quantile
a = sort(a(:));
q = a(max(1, ceil(prob * numel(a))));
end
