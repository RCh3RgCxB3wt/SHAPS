function pb = cond_ber_rayleigh(H2, EbN0_dB, p, L_ch, scheme)
% Conditional BER for given channels H2 (M x Nh), scheme: shaps/mc_ocdm/mc_ofdm
M = p.M; beta = p.beta; L_cp = p.L_cp;
Q = @(z) 0.5*erfc(z/sqrt(2));
if strcmp(scheme, 'shaps'), Kc = M; else, Kc = M - 1; end
g_eff = 10^(EbN0_dB/10) * Kc / (M + L_cp);
N0    = beta / g_eff;
al    = H2 ./ (H2 + N0);              % MMSE gain per bin
Nk    = N0 * H2 ./ (H2 + N0).^2;      % noise after MMSE
ab = mean(al, 1);  va = var(al, 1, 1);  Ne = mean(Nk, 1);
switch scheme
    case 'shaps'
        eS = 0;  if isfield(p, 'eta_S'), eS = p.eta_S; end
        snr = 2*ab.^4*beta ./ (Ne.*(2*ab.^2 + p.C_W*va + Ne) + eS*beta*ab.^2.*va);
        pb  = Q(sqrt(snr));
    case 'mc_ocdm'
        chi = p.chi_c * (M - L_ch);
        eta = p.eta;
        if isfield(p, 'eta_s'), eta = p.eta + p.eta_s*(L_ch - 5); end
        snr = 2*ab.^4*beta ./ (Ne.*(2*ab.^2 + chi*va + Ne) + eta*beta*ab.^2.*va);
        pb  = Q(sqrt(snr));
    case 'mc_ofdm'
        a0 = al(1, :);  ak = al(2:M, :);  n0 = Nk(1, :);  nk = Nk(2:M, :);
        snr = 2*(a0.*ak).^2*beta ./ (ak.^2.*n0 + a0.^2.*nk + n0.*nk);
        pb  = mean(Q(sqrt(snr)), 1);
    otherwise
        error('cond_ber_rayleigh: unknown scheme ''%s''', scheme);
end
end
