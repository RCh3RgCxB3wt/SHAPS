function [n_err, idx_rate] = shaps_rx_segment(seg, h, EbN0_dB, p, cfg, rs)
% Receive one segment over block-fading channel h
T = p.T_R;
V_prev = seg.U_plt;
n_err = 0;  n_idx = 0;
for t = 1:T
    [y, r_si] = channel_aug_rs(seg.x(:, t), seg.si(:, t), h, EbN0_dB, p.K, p, rs);
    if cfg.slm && ~strcmp(p.si_mode, 'genie')
        u_hat = slm_sideinfo_rx(r_si, p, h);
    else
        u_hat = seg.u(t);
    end
    n_idx = n_idx + (u_hat ~= seg.u(t));
    [b_hat, V_wal] = shaps_rx(y, V_prev, u_hat, h, EbN0_dB, p, cfg);
    if t > 1   % skip pilot frame
        n_err = n_err + sum(b_hat ~= seg.b(:, t));
    end
    V_prev = V_wal;
end
idx_rate = n_idx / T;
end
