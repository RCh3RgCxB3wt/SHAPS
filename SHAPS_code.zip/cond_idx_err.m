function pidx = cond_idx_err(h, EbN0_dB, p, rA)
% Union bound of SLM index error probability for each channel
if nargin < 4 || isempty(rA)
    r  = sort(si_amp_ratio(p));
    rA = r(max(1, round(((1:5) - 0.5)/5 * numel(r))));   % 5 quantiles
end
Q  = @(z) 0.5*erfc(z/sqrt(2));
T  = p.si_tab;  [n, U] = size(T);  L = size(h, 1);  Nh = size(h, 2);
[iu, iv] = find(triu(true(U), 1));
D  = T(:, iu) - T(:, iv);       % codeword differences
P  = numel(iu);
R  = zeros(L*L, P);
for a = 1:L
    for b = 1:L
        s = max(a, b) - 1;
        R((b-1)*L + a, :) = sum(D(1+s-(a-1):n-(a-1), :) .* D(1+s-(b-1):n-(b-1), :), 1);
    end
end
g    = 10.^(EbN0_dB(:).'/10);
pidx = zeros(numel(g), Nh);
ck   = 2e4;
for c0 = 1:ck:Nh
    c1 = min(c0 + ck - 1, Nh);  hc = h(:, c0:c1);
    HH = zeros(L*L, c1 - c0 + 1);
    for a = 1:L
        for b = 1:L
            HH((b-1)*L + a, :) = hc(a, :) .* conj(hc(b, :));
        end
    end
    d2 = max(real(R.' * HH), 0);    % squared distances
    for i = 1:numel(g)
        acc = 0;
        for r = 1:numel(rA)
            acc = acc + (2/U) * sum(Q(sqrt(rA(r)*g(i)*d2/2)), 1);
        end
        pidx(i, c0:c1) = min(acc / numel(rA), 1);
    end
end
end
