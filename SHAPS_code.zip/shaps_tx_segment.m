function seg = shaps_tx_segment(s, p, cfg, rs)
% Transmit one segment: pilot frame + T_R-1 data frames
M = p.M; K = p.K; T = p.T_R;
c     = chebyshev_chaos(p.beta, refresh_x0(s, p.KEY));
U_plt = repmat(c.', M, 1);
seg.x = complex(zeros(p.N, T));
if cfg.slm, seg.si = zeros(p.n_si, T); else, seg.si = zeros(0, T); end
seg.u = ones(1, T);
seg.b = ones(K, T);
U_prev = U_plt;
for t = 1:T
    if t == 1
        b = ones(K, 1);                                   % pilot frame
    else
        b = 2*randi(rs, [0 1], K, 1) - 1;
    end
    [x, U_dif, u_opt] = shaps_tx(b, U_prev, p, cfg);
    seg.x(:, t) = x;
    if cfg.slm, seg.si(:, t) = slm_sideinfo_tx(u_opt, x, p); end
    seg.u(t)    = u_opt;
    seg.b(:, t) = b;
    U_prev = U_dif;
end
seg.U_plt = U_plt;
end
