function [b_hat, V_wal] = shaps_rx_awgn(y, V_prev, u_hat, p, cfg)
% SHAPS receiver for AWGN (no equalizer)
M = p.M; beta = p.beta; L_cp = p.L_cp;
Y = reshape(y, M + L_cp, beta);
Y = Y(L_cp+1:end, :);                            % remove CP
V = p.A' * Y;                                    % DFnT
if cfg.slm,   V = V .* conj(p.G(:, :, u_hat)); end
if cfg.zc,    V = V .* conj(p.Za);             end
if cfg.walsh, V = V .* p.Wh(p.walsh_rows, :);  end
V_wal = V;
rho   = real(sum(V_wal .* conj(V_prev), 2));     % differential correlation
b_hat = sign(rho);
b_hat(b_hat == 0) = 1;
end
