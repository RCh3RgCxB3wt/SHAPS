function x0 = refresh_x0(s, key)
% Pilot initial value for segment s from the shared key
t  = mod(key*(s+1) + key^2*(s+1)^2, 1);
t  = 0.1 + 0.8*t;      % keep away from +-1
x0 = 0.9*(2*t - 1);
end
