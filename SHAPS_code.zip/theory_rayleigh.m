function [pb, se] = theory_rayleigh(EbN0_dB, p, L_ch, scheme)
% Semi-analytical Rayleigh BER averaged over random channels
if ~isfield(p, 'N_mc_chunk'), p.N_mc_chunk = 1e5; end
Nmc = p.N_mc;
if strcmp(scheme, 'shaps') && isfield(p, 'N_mc_shaps'), Nmc = p.N_mc_shaps; end
M  = p.M;
rs = RandStream('mt19937ar', 'Seed', 42);   % private stream
n_chunk = ceil(Nmc / p.N_mc_chunk);
acc = zeros(size(EbN0_dB));  acc2 = acc;  n_tot = 0;
for c = 1:n_chunk
    nc = min(p.N_mc_chunk, Nmc - n_tot);
    h  = (randn(rs, L_ch, nc) + 1j*randn(rs, L_ch, nc)) / sqrt(2*L_ch);
    H2 = abs(fft(h, M, 1)).^2;
    for i = 1:numel(EbN0_dB)
        v = cond_ber_rayleigh(H2, EbN0_dB(i), p, L_ch, scheme);
        acc(i)  = acc(i)  + sum(v);
        acc2(i) = acc2(i) + sum(v.^2);
    end
    n_tot = n_tot + nc;
end
pb = acc / n_tot;
se = sqrt(max(acc2/n_tot - pb.^2, 0) / n_tot);
end
