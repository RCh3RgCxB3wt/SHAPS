function [y, r_si] = awgn_aug(x, s_si, EbN0_dB, K, p)
% AWGN channel for the frame [x; zeros; s_si]
N     = numel(x);
x_aug = [x; zeros(p.L_cp, 1); s_si];
E = sum(abs(x).^2);
if p.eb_include_si, E = E + sum(abs(s_si).^2); end
N0 = (E / K) / 10^(EbN0_dB/10);   % Eb taken from payload only
y_aug = x_aug + sqrt(N0/2) * (randn(size(x_aug)) + 1j*randn(size(x_aug)));
y    = y_aug(1:N);
r_si = y_aug(N + p.L_cp + 1:end);
end
