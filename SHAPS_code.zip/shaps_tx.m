function [x, U_dif, u_opt] = shaps_tx(b, U_prev, p, cfg)
% SHAPS transmitter for one frame; cfg switches .walsh .zc .slm .mu

M = p.M; beta = p.beta; L_cp = p.L_cp; N = p.N;

U_dif = U_prev .* b(:);                            % differential encoding
U = U_dif;
if cfg.walsh, U = U .* p.Wh(p.walsh_rows, :); end
if cfg.zc,    U = U .* p.Za;                  end

if cfg.slm
    Ns = p.N_slm;
    U_all = U .* p.G;
    X_all = reshape(p.A * reshape(U_all, M, beta*Ns), M, beta, Ns);
    X_all = cat(1, X_all(end-L_cp+1:end, :, :), X_all);       % add CP
    x_all = reshape(X_all, N, Ns);
    if cfg.mu > 0
        x_all = mulaw_compand(x_all, cfg.mu);
    end
    [~, u_opt] = min(papr_db(x_all, p.O_s));                  % pick lowest PAPR
    x = x_all(:, u_opt);
else
    X = p.A * U;
    X = [X(end-L_cp+1:end, :); X];
    x = X(:);
    if cfg.mu > 0, x = mulaw_compand(x, cfg.mu); end
    u_opt = 1;
end
end


function y = mulaw_compand(x, mu0)
% mu-law companding, keeps phase and peak
Xmax = max(abs(x), [], 1) + 1e-12;
y = Xmax .* log1p(mu0*abs(x)./Xmax) ./ log1p(mu0) .* exp(1j*angle(x));
end
