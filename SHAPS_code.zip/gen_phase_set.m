function G = gen_phase_set(M, beta, N_slm)
% SLM phase masks, fixed seed so TX and RX match
saved = rng;
rng(12345, 'twister');
G = exp(1j*2*pi*rand(M, beta, N_slm));
G(:,:,1) = 1;
rng(saved);   % restore caller's RNG
end
