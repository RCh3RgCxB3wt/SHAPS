function papr = papr_db(x, os)
% Column-wise PAPR in dB with os-times oversampling
if nargin < 2, os = 4; end
[N, U] = size(x);
Xf = fft(x, [], 1);
Z  = complex(zeros(N*os, U));
% zero padding in frequency domain
Z(1:N/2, :)         = Xf(1:N/2, :);
Z(end-N/2+1:end, :) = Xf(N/2+1:end, :);
P = abs(ifft(Z, [], 1)).^2;
papr = 10*log10(max(P, [], 1) ./ mean(P, 1));
end
