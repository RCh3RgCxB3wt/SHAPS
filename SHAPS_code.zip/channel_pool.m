function [h, pb] = channel_pool(N_pool, L_ch, EbN0_dB, p, scheme, seed)
% Rayleigh channel pool and its conditional BER for each SNR
rs = RandStream('mt19937ar', 'Seed', seed);
h  = (randn(rs, L_ch, N_pool) + 1j*randn(rs, L_ch, N_pool)) / sqrt(2*L_ch);
nS = numel(EbN0_dB);
pb = zeros(nS, N_pool);
ck = 1e5;
% process in chunks to save memory
for c0 = 1:ck:N_pool
    c1 = min(c0 + ck - 1, N_pool);
    H2 = abs(fft(h(:, c0:c1), p.M, 1)).^2;
    for i = 1:nS
        pb(i, c0:c1) = cond_ber_rayleigh(H2, EbN0_dB(i), p, L_ch, scheme);
    end
end
end
