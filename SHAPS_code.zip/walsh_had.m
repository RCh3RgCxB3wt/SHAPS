function H = walsh_had(N)
% N x N Walsh-Hadamard matrix (Sylvester)
assert(N == 2^round(log2(N)), 'N must be a power of 2');
H = 1;
while size(H,1) < N
    H = [H H; H -H];
end
end
