% AWGN BER: simulation vs theory for SHAPS, MDCSK-OCDM and MDCSK-OFDM

EbN0_dB = 0:2:16;

p   = shaps_params(8);
cfg = struct('walsh', 1, 'zc', 1, 'slm', 1, 'mu', p.mu0);   % full SHAPS chain

sim.N_min = 5000; sim.N_max = 100000; sim.err_target = 200; sim.batch = 500;

out_dir = 'results_awgn';
if ~exist(out_dir, 'dir'), mkdir(out_dir); 
end

n = numel(EbN0_dB);
ber = zeros(3, n); idx_err = zeros(1, n);
fprintf(' Eb/N0 |  SHAPS sim   Eq.(27)   | MC-OCDM sim | MC-OFDM sim | Eq.(28)   | idx err\n');
for i = 1:n
    s = EbN0_dB(i);
    sim.seed = 1000 + i;  r1 = sim_shaps_awgn(s, p, cfg, sim);
    sim.seed = 2000 + i;  r2 = sim_mcdcsk_awgn(s, p, 'ocdm', sim);
    sim.seed = 3000 + i;  r3 = sim_mcdcsk_awgn(s, p, 'ofdm', sim);
    ber(:, i) = [r1.ber; r2.ber; r3.ber];  idx_err(i) = r1.idx_err;
    fprintf('  %4.1f | %.3e  %.3e | %.3e   | %.3e   | %.3e | %.1e\n', s, r1.ber, ...
            theory_awgn(s, p, 'shaps'), r2.ber, r3.ber, theory_awgn(s, p, 'mc'), r1.idx_err);
end

% theory curves on a fine grid
Ef = linspace(EbN0_dB(1), EbN0_dB(end), 161);
th_s = theory_awgn(Ef, p, 'shaps');  
th_m = theory_awgn(Ef, p, 'mc');
fig = ber_figure(Ef, {th_s, th_m, th_m}, EbN0_dB, ber, '-.');
ylim([1e-5 1]);
saveas(fig, fullfile(out_dir, 'ber_awgn.png'));
savefig(fig, fullfile(out_dir, 'ber_awgn.fig'));
