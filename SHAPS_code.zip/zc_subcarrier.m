function Za = zc_subcarrier(M, beta)
% Zadoff-Chu phase matrix, one root per subcarrier
Za = zeros(M, beta);
k  = 0:beta-1;
for m = 1:M
    r = 2*m - 1;
    while gcd(r, beta) ~= 1    % root must be coprime with beta
        r = r + 2;
    end
    Za(m, :) = exp(-1j*pi*r*k.*(k+1)/beta);
end
end
