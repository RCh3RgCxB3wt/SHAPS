function rA = si_amp_ratio(p, n_seg)
% Samples of A_si^2/E_b (cached per L_cp)
persistent cache
if nargin < 2, n_seg = 5; end
key = sprintf('L%d_%d', p.L_cp, n_seg);
if isstruct(cache) && isfield(cache, key), rA = cache.(key); return; end
cfg = struct('walsh', 1, 'zc', 1, 'slm', 1, 'mu', p.mu0);
rs  = RandStream('mrg32k3a', 'Seed', 4242);
rA  = [];
for s = 0:n_seg-1
    seg = shaps_tx_segment(s, p, cfg, rs);
    E   = sum(abs(seg.x).^2, 1) / p.K;                 % Eb per frame
    rA  = [rA, max(abs(seg.x), [], 1).^2 ./ E];        %#ok<AGROW>
end
if ~isstruct(cache), cache = struct(); end
cache.(key) = rA;
end
