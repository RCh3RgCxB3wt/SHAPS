function [x, b] = mcdcsk_tx(B, p, basis)
% Classical MDCSK transmitter for B frames
% basis: 'ocdm' | 'ofdm' | 'ci_ofdm' | 'dct_ofdm'
M = p.M; beta = p.beta; L_cp = p.L_cp;
Kc  = M - 1;
b   = 2*randi([0 1], Kc, B) - 1;
Phi = zeros(beta, B);
for f = 1:B
    x0 = (2*randi([0 1]) - 1) * (0.1 + 0.8*rand);
    Phi(:, f) = chebyshev_chaos(beta, x0);
end
U = zeros(M, beta, B);
U(1, :, :)   = reshape(Phi, 1, beta, B);           % reference subcarrier
U(2:M, :, :) = reshape(b, Kc, 1, B) .* reshape(Phi, 1, beta, B);
switch basis
    case 'ocdm'
        X = reshape(p.A * reshape(U, M, beta*B), M, beta, B);
    case 'ofdm'
        X = ifft(U, M, 1) * sqrt(M);
    case {'ci_ofdm', 'dct_ofdm'}
        S = spread_matrix(M, basis(1:end-5));                 % 'ci' or 'dct'
        U = reshape(S * reshape(U, M, beta*B), M, beta, B);
        X = ifft(U, M, 1) * sqrt(M);
    otherwise
        error('mcdcsk_tx: unknown basis ''%s''', basis);
end
X = cat(1, X(end-L_cp+1:end, :, :), X);   % add CP
x = reshape(X, p.N, B);
end
