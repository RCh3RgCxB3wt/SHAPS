function pb = theory_awgn(EbN0_dB, p, scheme)
% Closed-form AWGN BER, scheme: 'shaps' | 'mc'
gb = 10.^(EbN0_dB/10);
switch scheme
    case 'shaps', g = gb * p.M     / (p.M + p.L_cp);
    case 'mc',    g = gb * (p.M-1) / (p.M + p.L_cp);
    otherwise,    error('theory_awgn: unknown scheme ''%s''', scheme);
end
pb = 0.5 * erfc( sqrt(2*g.^2 ./ (p.beta + 2*g)) / sqrt(2) );
end
