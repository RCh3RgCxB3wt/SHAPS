function c = chebyshev_chaos(beta, x0)
%CHEBYSHEV_CHAOS  Chebyshev chaotic sequence, Eq. (2):  c[k+1] = 1 - 2 c[k]^2.
%   The sequence starts from c[1] = x0 (|x0| < 1), is made zero-mean and
%   scaled so that sum(c.^2) = beta.  Output: beta x 1 real vector.
assert(abs(x0) < 1, 'chebyshev_chaos: |x0| must be < 1');
c = zeros(beta, 1);
c(1) = x0;
for k = 1:beta-1
    v = 1 - 2*c(k)^2;
    if abs(v) > 1, v = sign(v)*0.999; end      % numerical guard
    c(k+1) = v;
end
c = c - mean(c);
c = c * sqrt(beta / sum(c.^2));
end
