function Za = zc_subcarrier(M, beta)
%ZC_SUBCARRIER  M x beta Zadoff-Chu phase matrix, Eq. (6).
%   Za(m,k) = exp(-j*pi*r_m*k*(k+1)/beta), k = 0..beta-1, with odd root
%   r_m = 2m-1 adjusted to be coprime with beta.  |Za| = 1.
Za = zeros(M, beta);
k  = 0:beta-1;
for m = 1:M
    r = 2*m - 1;
    while gcd(r, beta) ~= 1
        r = r + 2;
    end
    Za(m, :) = exp(-1j*pi*r*k.*(k+1)/beta);
end
end
