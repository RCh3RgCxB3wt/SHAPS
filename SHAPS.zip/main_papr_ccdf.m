%MAIN_PAPR_CCDF  PAPR CCDF of SHAPS-MDCSK-OCDM (four-stage chain on and off),
%   MDCSK-OCDM and MDCSK-OFDM (Fig. 6, Table 6).
%   Output: results_papr/.   MATLAB R2024b, no toolbox required.

N_frames = 20000;                  % frames per scheme (multiple of T_R)

SEED     = 2024;

p = shaps_params(8);
cfg_on  = struct('walsh', 1, 'zc', 1, 'slm', 1, 'mu', p.mu0);
cfg_off = struct('walsh', 0, 'zc', 0, 'slm', 0, 'mu', 0);
rng(SEED, 'twister');

n_seg = ceil(N_frames / p.T_R);  N_frames = n_seg * p.T_R;
papr_on = zeros(N_frames, 1);  papr_off = zeros(N_frames, 1);
fprintf('PAPR of %d frames per scheme ...\n', N_frames);  t0 = tic;
i = 0;
for s = 0:n_seg-1
    c = chebyshev_chaos(p.beta, refresh_x0(s, p.KEY));
    U = repmat(c.', p.M, 1);                         % pilot state, Eq. (2)
    for t = 1:p.T_R
        if t == 1, b = ones(p.K, 1); else, b = 2*randi([0 1], p.K, 1) - 1; end
        [x_on, U_next] = shaps_tx(b, U, p, cfg_on);
        x_off          = shaps_tx(b, U, p, cfg_off);  % same state, no shaping
        i = i + 1;
        papr_on(i)  = papr_db(x_on,  p.O_s);
        papr_off(i) = papr_db(x_off, p.O_s);
        U = U_next;
    end
end
papr_oc = zeros(N_frames, 1);  papr_of = zeros(N_frames, 1);
B = 500;
for k = 1:B:N_frames
    nb = min(B, N_frames - k + 1);
    papr_oc(k:k+nb-1) = papr_db(mcdcsk_tx(nb, p, 'ocdm'), p.O_s).';
    papr_of(k:k+nb-1) = papr_db(mcdcsk_tx(nb, p, 'ofdm'), p.O_s).';
end
fprintf('done in %.1f s\n', toc(t0));

% ---- statistics ----
names = {'SHAPS-MDCSK-OCDM (four-stage ON)'; 'SHAPS-MDCSK-OCDM (bare, shaping off)'; ...
         'MDCSK-OFDM'; 'MDCSK-OCDM'};
data  = {papr_on, papr_off, papr_of, papr_oc};
S = zeros(4, 3);
for k = 1:4
    S(k, :) = [median(data{k}), q_tail(data{k}, 0.99), max(data{k})];
end
stats = table(names, S(:,1), S(:,2), S(:,3), 'VariableNames', {'scheme', 'median_dB', 'p99_dB', 'max_dB'});
disp(stats);
fprintf('Reduction vs MDCSK-OCDM: median %.2f dB, 99%% %.2f dB\n', S(4,1)-S(1,1), S(4,2)-S(1,2));
fprintf('Reduction vs MDCSK-OFDM: median %.2f dB, 99%% %.2f dB\n', S(3,1)-S(1,1), S(3,2)-S(1,2));

% ---- CCDF figure ----
xx = linspace(4, 18, 561);
ccdf = @(a) mean(a(:) > xx, 1);
fig = figure('Color', 'w', 'Position', [100 100 640 560]);
semilogy(xx, ccdf(papr_on), 'b-',  'LineWidth', 2); hold on;
semilogy(xx, ccdf(papr_oc), 'r-',  'LineWidth', 2);
semilogy(xx, ccdf(papr_of), '-',   'Color', [0 0.8 0], 'LineWidth', 2);
semilogy(xx, ccdf(papr_off), 'k--', 'LineWidth', 1.2);
yline(1e-2, ':', '99% (CCDF = 10^{-2})', 'Color', [.4 .4 .4], 'LabelHorizontalAlignment', 'left');
grid on; ylim([1e-3 1]); xlim([xx(1) xx(end)]);


xlabel('PAPR (dB)'); 

ylabel('CCDF');

legend(sprintf('SHAPS-MDCSK-OCDM (med %.2f dB)', S(1,1)), sprintf('MDCSK-OCDM (med %.2f dB)', S(4,1)), ...
       sprintf('MDCSK-OFDM (med %.2f dB)', S(3,1)), sprintf('SHAPS, shaping off (med %.2f dB)', S(2,1)), ...
       'Location', 'northeast', 'FontSize', 9);

out_dir = 'results_papr';
if ~exist(out_dir, 'dir'), mkdir(out_dir); 
end
saveas(fig, fullfile(out_dir, 'papr_ccdf.png'));
savefig(fig, fullfile(out_dir, 'papr_ccdf.fig'));




function q = q_tail(a, prob)
% Empirical quantile without the Statistics Toolbox.
a = sort(a(:));
q = a(max(1, ceil(prob * numel(a))));
end
