function [y, r_si] = awgn_aug(x, s_si, EbN0_dB, K, p)
%AWGN_AUG  AWGN channel for the augmented frame [x; 0_(L_cp); s_si],
%   Eqs. (12)-(13). Payload and side information share the noise density
%   N0 = Eb/(Eb/N0), with Eb = sum|x|^2/K over the payload only (unless
%   p.eb_include_si is true).
N     = numel(x);
x_aug = [x; zeros(p.L_cp, 1); s_si];
E = sum(abs(x).^2);
if p.eb_include_si, E = E + sum(abs(s_si).^2); end
N0 = (E / K) / 10^(EbN0_dB/10);
y_aug = x_aug + sqrt(N0/2) * (randn(size(x_aug)) + 1j*randn(size(x_aug)));
y    = y_aug(1:N);
r_si = y_aug(N + p.L_cp + 1:end);
end
