function p = shaps_params(L_cp)
%SHAPS_PARAMS  System parameters of SHAPS-MDCSK-OCDM (Table 1 of the paper)
%   and the matrices pre-stored identically at both ends (Sec. 2.2).
%
%   p = shaps_params()      uses L_cp = 8 (Table 1)
%   Identical to the side-information code of the full (Rayleigh) code base.

if nargin < 1 || isempty(L_cp), L_cp = 8; end

% ---- Table 1 ---------------------------------------------------------
p.M     = 32;                     % number of chirp subcarriers
p.beta  = 64;                     % chaotic spreading length (chips/subcarrier)
p.K     = p.M;                    % information bits per SHAPS frame (K = M)
p.L_cp  = L_cp;                   % cyclic-prefix length
p.T_R   = 50;                     % pilot refresh period (frames)
p.KEY   = 0.618033988749895;      % shared secret key kappa
p.N_slm = 16;                     % number of SLM candidate phase masks
p.mu0   = 8;                      % mu-law companding factor
p.O_s   = 4;                      % oversampling factor of the PAPR metric
p.N     = (p.M + p.L_cp) * p.beta;% payload samples per frame

% ---- Side information (stage T8) --------------------------------------
%   The SLM index u (1..N_slm) is sent as row u of the n_si x n_si Sylvester
%   Walsh-Hadamard matrix, multiplied chip by chip by a fixed +-1 scrambling
%   signature q (shared by both ends) and scaled to the payload peak
%   A_si = max|x| (Sec. 2.3, stage T8).
%   si_mode: 'peak'  : block at amplitude max|x| (does not raise the PAPR)  (default)
%            'genie' : receiver is handed the true index (ideal side information)
p.si_mode       = 'peak';
p.eb_include_si = false;          % Eb over the payload only, as in the paper

p.n_b  = ceil(log2(p.N_slm));     % index bits (4)
p.n_si = 32;                      % side-information chips (Table 1)
saved = rng;
rng(777, 'twister');              % fixed +-1 signature, identical at both ends
p.si_sig = 2*randi([0 1], p.n_si, 1) - 1;
rng(saved);
Hs = walsh_had(p.n_si);                        % 32 x 32
p.si_tab = p.si_sig .* Hs(:, 1:p.N_slm);       % column u = codeword of index u

% ---- Pre-stored matrices (Sec. 2.2) -------------------------------------
p.A  = chirp_basis(p.M);                       % IDFnT matrix
p.Wh = walsh_had(p.beta);                      % Walsh-Hadamard
p.Za = zc_subcarrier(p.M, p.beta);             % Zadoff-Chu phases
p.G  = gen_phase_set(p.M, p.beta, p.N_slm);    % SLM masks
p.walsh_rows = mod((0:p.M-1).', p.beta) + 1;   % row(m)
end
