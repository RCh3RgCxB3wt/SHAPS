function [x, U_dif, u_opt] = shaps_tx(b, U_prev, p, cfg)
%SHAPS_TX  SHAPS-MDCSK-OCDM transmitter for one frame, stages T1-T8.
%     b      : M x 1 bipolar bits (+-1)
%     U_prev : M x beta previous differential state (pilot or last U_dif)
%     cfg    : stage switches .walsh .zc .slm (0/1) and .mu (0 = off, else mu0)
%     x      : N x 1 transmitted payload
%     U_dif  : M x beta differential state, cached as next frame's reference
%     u_opt  : selected SLM index (1 when SLM is off)

M = p.M; beta = p.beta; L_cp = p.L_cp; N = p.N;

U_dif = U_prev .* b(:);                            % T1, time-frame differential
U = U_dif;
if cfg.walsh, U = U .* p.Wh(p.walsh_rows, :); end  % T2, Walsh spreading
if cfg.zc,    U = U .* p.Za;                  end  % T3, Zadoff-Chu precoding

if cfg.slm
    Ns = p.N_slm;
    U_all = U .* p.G;                                         % T4, M x beta x Ns
    X_all = reshape(p.A * reshape(U_all, M, beta*Ns), M, beta, Ns);   % T5
    X_all = cat(1, X_all(end-L_cp+1:end, :, :), X_all);       % T6, CP
    x_all = reshape(X_all, N, Ns);                            % T6, P/S
    if cfg.mu > 0
        x_all = mulaw_compand(x_all, cfg.mu);                 % T7
    end
    [~, u_opt] = min(papr_db(x_all, p.O_s));                  % T8
    x = x_all(:, u_opt);
else
    X = p.A * U;                                   % T5
    X = [X(end-L_cp+1:end, :); X];                 % T6
    x = X(:);
    if cfg.mu > 0, x = mulaw_compand(x, cfg.mu); end   % T7
    u_opt = 1;
end
end


function y = mulaw_compand(x, mu0)
% Column-wise mu-law companding; phase kept, peak X_max unchanged.
Xmax = max(abs(x), [], 1) + 1e-12;
y = Xmax .* log1p(mu0*abs(x)./Xmax) ./ log1p(mu0) .* exp(1j*angle(x));
end
