function r = sim_mcdcsk_awgn(EbN0_dB, p, basis, sim)
%SIM_MCDCSK_AWGN  Monte-Carlo BER of MC-DCSK-OCDM ('ocdm') or MC-DCSK-OFDM
%   ('ofdm') over AWGN (Sec. 3.2). Frames are independent and processed in
%   batches of sim.batch; every frame has its own chaotic reference.
rng(sim.seed, 'twister');
M = p.M; beta = p.beta; L_cp = p.L_cp; N = p.N;
Kc = M - 1;  Bt = sim.batch;  g = 10^(EbN0_dB/10);
n_err = 0; n_bit = 0; n_frames = 0;
while true
    [x, b] = mcdcsk_tx(Bt, p, basis);
    N0 = sum(abs(x).^2, 1) / Kc / g;
    y  = x + sqrt(N0/2) .* (randn(N, Bt) + 1j*randn(N, Bt));
    Y = reshape(y, M + L_cp, beta, Bt);
    Y = Y(L_cp+1:end, :, :);
    if strcmp(basis, 'ocdm')
        V = reshape(p.A' * reshape(Y, M, beta*Bt), M, beta, Bt);
    else
        V = fft(Y, M, 1) / sqrt(M);
    end
    rho   = real(sum(V(2:M, :, :) .* conj(V(1, :, :)), 2));
    b_hat = sign(reshape(rho, Kc, Bt));
    b_hat(b_hat == 0) = 1;
    n_err    = n_err + sum(b_hat(:) ~= b(:));
    n_bit    = n_bit + Kc*Bt;
    n_frames = n_frames + Bt;
    if n_frames >= sim.N_max, break; end
    if n_frames >= sim.N_min && n_err >= sim.err_target, break; end
end
r.ber = n_err / n_bit;  r.n_err = n_err;  r.n_bit = n_bit;  r.n_frames = n_frames;
end
