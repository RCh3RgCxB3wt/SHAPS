function x0 = refresh_x0(s, key)
%REFRESH_X0  Pilot seed for segment s (s = 0,1,2,...), Eq. (1).
%   t  = mod(key*(s+1) + key^2*(s+1)^2, 1)
%   t  = 0.1 + 0.8*t           (keeps x0 away from the end points +-1)
%   x0 = 0.9*(2t - 1)          so |x0| <= 0.72
%   Both ends compute the same x0 from the shared key and segment index.
t  = mod(key*(s+1) + key^2*(s+1)^2, 1);
t  = 0.1 + 0.8*t;
x0 = 0.9*(2*t - 1);
end
