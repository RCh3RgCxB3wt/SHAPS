function pb = theory_awgn(EbN0_dB, p, scheme)
%THEORY_AWGN  Closed-form AWGN BER.
%   scheme = 'shaps' : Eq. (30), gamma_eff = gamma_b * M     / (M + L_cp)
%   scheme = 'mc'    : Eq. (31), gamma_eff = gamma_b * (M-1) / (M + L_cp)
%                      (MC-DCSK-OCDM and MC-DCSK-OFDM share this expression)
%   Pb = Q( sqrt( 2*gamma_eff^2 / (beta + 2*gamma_eff) ) )
gb = 10.^(EbN0_dB/10);
switch scheme
    case 'shaps', g = gb * p.M     / (p.M + p.L_cp);
    case 'mc',    g = gb * (p.M-1) / (p.M + p.L_cp);
    otherwise,    error('theory_awgn: unknown scheme ''%s''', scheme);
end
pb = 0.5 * erfc( sqrt(2*g.^2 ./ (p.beta + 2*g)) / sqrt(2) );
end
