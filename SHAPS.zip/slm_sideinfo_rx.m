function u_hat = slm_sideinfo_rx(r_si, p)
%SLM_SIDEINFO_RX  Decode the SLM index from the received side information
%   (stage R5, AWGN branch). Generalized-likelihood rule of the paper,
%       u_hat = arg max_u  max(Re{t_u' r_si}, 0)^2 / ||t_u||^2,
%   with t_u = q .* w_u (no channel filtering under AWGN). All codewords are
%   orthogonal with equal norm, so this is descrambling by q followed by a
%   32-point Walsh-Hadamard transform; the amplitude A_si is not needed.
met   = real(p.si_tab.' * r_si);                       % N_slm x 1
score = max(met, 0).^2 ./ sum(abs(p.si_tab).^2, 1).';
[~, u_hat] = max(score);
end
