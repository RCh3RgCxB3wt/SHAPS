function papr = papr_db(x, os)
%PAPR_DB  Column-wise PAPR (dB) of the os-times oversampled waveform
%   (frequency-domain zero padding followed by an oversampled IFFT).
%   x : N x U (N even).  papr : 1 x U.
if nargin < 2, os = 4; end
[N, U] = size(x);
Xf = fft(x, [], 1);
Z  = complex(zeros(N*os, U));
Z(1:N/2, :)         = Xf(1:N/2, :);
Z(end-N/2+1:end, :) = Xf(N/2+1:end, :);
P = abs(ifft(Z, [], 1)).^2;
papr = 10*log10(max(P, [], 1) ./ mean(P, 1));
end
