function fig = ber_figure(x_th, th, x_sim, ber, ls)
%BER_FIGURE  Paper-style BER plot: theory as lines, simulation as markers.
%   th  : {SHAPS, MDCSK-OCDM, MDCSK-OFDM} theory vectors on x_th
%   ber : 3 x numel(x_sim) simulated BER (zeros are not drawn)
if nargin < 5, ls = '-'; end
col = {[0 0 1], [0.9 0 0], [0 0.8 0]};  
mk = {'o', 's', '^'};
fig = figure('Position', [100 100 600 560], 'Color', 'w');
for k = 1:3
    semilogy(x_th, th{k}, ls, 'Color', col{k}, 'LineWidth', 1.5); hold on;
end
for k = 1:3
    v = ber(k, :) > 0;
    semilogy(x_sim(v), ber(k, v), mk{k}, 'Color', col{k}, 'MarkerFaceColor', col{k}, ...
             'MarkerSize', 7, 'LineStyle', 'none');
end
grid on; box on; 
set(gca, 'YMinorGrid', 'on', 'FontSize', 11);
%xlabel('E_b/N_0 (dB)'); 
xlabel('$E_{\mathrm{b}}/N_{\mathrm{0}}$ (dB)', 'Interpreter', 'latex', 'FontSize', 11)
ylabel('BER', 'FontSize', 11);

legend({'SHAPS-MDCSK-OCDM Theory', 'MDCSK-OCDM Theory', 'MDCSK-OFDM Theory', ...
        'SHAPS-MDCSK-OCDM Simulated', 'MDCSK-OCDM Simulated', 'MDCSK-OFDM Simulated'}, ...
       'Location', 'southwest', 'FontSize', 9);
end
