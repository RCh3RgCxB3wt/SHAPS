function s_si = slm_sideinfo_tx(u_opt, x, p)
%SLM_SIDEINFO_TX  Side-information block carrying the SLM index (stage T8):
%   s_si = A_si * (q .* w_u), w_u = Walsh row u_opt of length n_si = 32,
%   q = fixed +-1 scrambling signature (p.si_sig), A_si = max|x|.
switch p.si_mode
    case 'peak',  A_si = max(abs(x));
    case 'genie', A_si = 1;
    otherwise, error('slm_sideinfo_tx: unknown si_mode ''%s''', p.si_mode);
end
s_si = A_si * p.si_tab(:, u_opt);
end
