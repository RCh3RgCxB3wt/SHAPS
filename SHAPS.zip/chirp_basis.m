function A = chirp_basis(M)
%CHIRP_BASIS  OCDM modulation matrix (inverse discrete Fresnel transform).
%   A(n+1,m+1) = M^(-1/2) * exp(-j*pi/4) * exp(j*pi*(n-m)^2/M),  Eq. (8).
%   A is unitary: A'*A = I.  IDFnT: X = A*U.   DFnT: U = A'*X.
assert(mod(M,2) == 0, 'M must be even');
n = (0:M-1).';  m = 0:M-1;
A = exp(-1j*pi/4) / sqrt(M) * exp(1j*pi/M * (n - m).^2);
end
