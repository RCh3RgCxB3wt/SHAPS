function [x, b] = mcdcsk_tx(B, p, basis)
%MCDCSK_TX  Classical multicarrier DCSK transmitter for B frames.
%   Subcarrier 1 carries the chaotic reference c, subcarriers 2..M carry
%   b(m)*c. Each frame uses its own chaotic sequence (random |x0| in [0.1,0.9]).
%   basis = 'ocdm' (chirp basis A) or 'ofdm' (IFFT basis, Kaddoum et al.).
%   x : N x B transmitted frames;  b : (M-1) x B bits
M = p.M; beta = p.beta; L_cp = p.L_cp;
Kc  = M - 1;
b   = 2*randi([0 1], Kc, B) - 1;
Phi = zeros(beta, B);
for f = 1:B
    x0 = (2*randi([0 1]) - 1) * (0.1 + 0.8*rand);
    Phi(:, f) = chebyshev_chaos(beta, x0);
end
U = zeros(M, beta, B);
U(1, :, :)   = reshape(Phi, 1, beta, B);
U(2:M, :, :) = reshape(b, Kc, 1, B) .* reshape(Phi, 1, beta, B);
switch basis
    case 'ocdm', X = reshape(p.A * reshape(U, M, beta*B), M, beta, B);
    case 'ofdm', X = ifft(U, M, 1) * sqrt(M);
    otherwise,   error('mcdcsk_tx: unknown basis ''%s''', basis);
end
X = cat(1, X(end-L_cp+1:end, :, :), X);
x = reshape(X, p.N, B);
end
