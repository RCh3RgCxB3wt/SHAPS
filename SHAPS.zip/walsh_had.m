function H = walsh_had(N)
%WALSH_HAD  N x N Walsh-Hadamard matrix (Sylvester construction), entries +-1.
%   H*H.' = N*I.  N must be a power of two.
assert(N == 2^round(log2(N)), 'N must be a power of 2');
H = 1;
while size(H,1) < N
    H = [H H; H -H];
end
end
