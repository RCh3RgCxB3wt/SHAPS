function [b_hat, V_wal] = shaps_rx_awgn(y, V_prev, u_hat, p, cfg)
%SHAPS_RX_AWGN  SHAPS-MDCSK-OCDM receiver on the AWGN branch
%   (R0, R4, R6-R8, R10; the equalization core R1-R3 is not needed).
%   V_prev : reference (de-Walsh output of the previous frame or of the
%            received pilot frame);  V_wal : reference for the next frame
M = p.M; beta = p.beta; L_cp = p.L_cp;
Y = reshape(y, M + L_cp, beta);                  % R0
Y = Y(L_cp+1:end, :);
V = p.A' * Y;                                    % R4, DFnT
if cfg.slm,   V = V .* conj(p.G(:, :, u_hat)); end   % R6
if cfg.zc,    V = V .* conj(p.Za);             end   % R7
if cfg.walsh, V = V .* p.Wh(p.walsh_rows, :);  end   % R8
V_wal = V;
rho   = real(sum(V_wal .* conj(V_prev), 2));     % R10
b_hat = sign(rho);
b_hat(b_hat == 0) = 1;
end
