function r = sim_shaps_awgn(EbN0_dB, p, cfg, sim)
%SIM_SHAPS_AWGN  Monte-Carlo BER of SHAPS-MDCSK-OCDM over AWGN.
%
%   Frame structure: a pilot frame (bits = +1) every T_R frames, generated
%   from the key and the segment index (T0) and transmitted with its side
%   information; the receiver uses its de-Walsh output as reference for the
%   first data frame (R9). Errors are counted on data frames only.
%
%   sim.N_min / N_max : min / max data frames;  sim.err_target ; sim.seed
%   r.ber, r.n_err, r.n_bit, r.n_frames, r.idx_err (SLM index error rate)

rng(sim.seed, 'twister');
M = p.M; K = p.K;
n_err = 0; n_bit = 0; n_data = 0; n_idx_err = 0; n_tx = 0;
f = 0; U_tx = []; V_rx = [];

while true
    f = f + 1;
    is_pilot = (mod(f-1, p.T_R) == 0);
    if is_pilot
        s = floor((f-1) / p.T_R);
        c = chebyshev_chaos(p.beta, refresh_x0(s, p.KEY));
        U_plt = repmat(c.', M, 1);
        b = ones(K, 1);
        U_ref_tx = U_plt;  V_ref_rx = U_plt;
    else
        b = 2*randi([0 1], K, 1) - 1;
        U_ref_tx = U_tx;  V_ref_rx = V_rx;
    end

    [x, U_dif, u_opt] = shaps_tx(b, U_ref_tx, p, cfg);            % T1-T8
    if cfg.slm
        s_si = slm_sideinfo_tx(u_opt, x, p);
    else
        s_si = zeros(0, 1);
    end
    [y, r_si] = awgn_aug(x, s_si, EbN0_dB, K, p);

    if cfg.slm && ~strcmp(p.si_mode, 'genie')
        u_hat = slm_sideinfo_rx(r_si, p);                      % R5
    else
        u_hat = u_opt;
    end
    n_idx_err = n_idx_err + (u_hat ~= u_opt);
    n_tx = n_tx + 1;

    [b_hat, V_wal] = shaps_rx_awgn(y, V_ref_rx, u_hat, p, cfg);

    if ~is_pilot
        n_err  = n_err + sum(b_hat ~= b);
        n_bit  = n_bit + K;
        n_data = n_data + 1;
    end
    U_tx = U_dif;  V_rx = V_wal;

    % stop only at the end of a 50-frame segment
    if mod(f, p.T_R) == 0
        if n_data >= sim.N_max, break; end
        if n_data >= sim.N_min && n_err >= sim.err_target, break; end
    end
end
r.ber      = n_err / max(n_bit, 1);
r.n_err    = n_err;
r.n_bit    = n_bit;
r.n_frames = n_data;
r.idx_err  = n_idx_err / max(n_tx, 1);
end
