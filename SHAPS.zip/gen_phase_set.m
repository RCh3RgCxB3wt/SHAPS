function G = gen_phase_set(M, beta, N_slm)
%GEN_PHASE_SET  M x beta x N_slm SLM phase masks G_u, Eq. (7).
%   G(:,:,u) = exp(j*2*pi*theta_u), |G| = 1, and G(:,:,1) = 1 (do-nothing
%   branch). The table is generated from a fixed seed, so transmitter and
%   receiver hold identical copies. The caller's RNG state is restored.
saved = rng;
rng(12345, 'twister');
G = exp(1j*2*pi*rand(M, beta, N_slm));
G(:,:,1) = 1;
rng(saved);
end
